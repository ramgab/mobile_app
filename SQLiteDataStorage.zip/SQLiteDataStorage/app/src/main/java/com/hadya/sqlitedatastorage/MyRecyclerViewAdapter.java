package com.hadya.sqlitedatastorage;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {

    private ArrayList<String[]> mData;
    private LayoutInflater mInflater;

    // data is passed into the constructor
    MyRecyclerViewAdapter(Context context, ArrayList<String[]> data) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
    }

    // inflates the row layout from xml when needed
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.recyclerview_row, parent, false);
        return new ViewHolder(view);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        String[] rows = mData.get(position);
        holder.idDB.setText(rows[0]);
        holder.todoDB.setText(rows[1]);
        holder.dateDB.setText(rows[2]);
        holder.timeDB.setText(rows[3]);
        holder.categoryDB.setText(rows[4]);
    }

    // total number of rows
    @Override
    public int getItemCount() {
        return mData.size();
    }


    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView idDB,todoDB,dateDB,timeDB,categoryDB;

        ViewHolder(View itemView) {
            super(itemView);
            idDB = itemView.findViewById(R.id.idDB);
            todoDB = itemView.findViewById(R.id.todoDB);
            dateDB = itemView.findViewById(R.id.dateDB);
            timeDB = itemView.findViewById(R.id.timeDB);
            categoryDB = itemView.findViewById(R.id.categoryDB);
        }

    }



}
