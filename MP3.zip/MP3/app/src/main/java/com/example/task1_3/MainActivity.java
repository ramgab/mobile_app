package com.example.task1_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tvInfo;
    EditText etInput;
    Button bControl;
    int a=0;
    int b=100;
    int number1 = a + (int) (Math.random() * b);
    String s;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvInfo = (TextView)findViewById(R.id.textView1);
        etInput = (EditText)findViewById(R.id.editText1);
        bControl = (Button)findViewById(R.id.button1);

    }
    public void onClick(View v){
        String a = etInput.getText().toString();
        int q = Integer.parseInt(a);

        if (q>number1){
            s="Загаданное число меньше "+q+number1;
        }
        if (q<number1){
            s="Загаданное число больше "+q+number1;
        }
        if (q==number1) {
            s = "Ура, победа" + q + number1;
        }
        etInput.getText().clear();
        tvInfo.setText(s.toCharArray(), 0, s.length());
    }
}
